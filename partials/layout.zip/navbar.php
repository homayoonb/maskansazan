<?php
$baseUrl = '/maskansazan';

$currentPage = basename($_SERVER['PHP_SELF']);
$projectPages = [
        'mehr.php' => 'مهر',
        'toranj.php' => 'ترنج',
        'garmdareh1.php' => 'نقشه‌برداری ۱',
        'garmdareh2.php' => 'نقشه‌برداری ۲',
        'ordibehesht.php' => 'اردیبهشت',
        'sabat.php' => 'ساباط',
        'polaris.php' => 'پلاریس'
];

// مسیر پایه همیشه صفحه اصلی است
$breadcrumb = [
        'صفحه اصلی' => $baseUrl . '/index.php'
];

// اگر صفحه فعلی جزو پروژه‌ها باشد
if (array_key_exists($currentPage, $projectPages)) {
    $breadcrumb['پروژه‌ها'] = ''; // بدون لینک
    $breadcrumb[$projectPages[$currentPage]] = $baseUrl . '/pages/' . $currentPage;
}
// در غیر این صورت، صفحات معمولی
else {
    switch ($currentPage) {
        case 'goals.php':
            $breadcrumb['اهداف'] = $baseUrl . '/pages/goals.php';
            break;
        case 'groupIntroduction.php':
            $breadcrumb['معرفی گروه'] = $baseUrl . '/pages/groupIntroduction.php';
            break;
        case 'garmdareh1.php':
            $breadcrumb['نقشه برداری ۱'] = $baseUrl . '/pages/garmdareh1.php';
            break;
        case 'garmdareh2.php':
            $breadcrumb['نقشه برداری 2'] = $baseUrl . '/pages/garmdareh2.php';
            break;
        case 'ordibehesht.php':
            $breadcrumb['اردیبهشت']= $baseUrl . '/pages/ordibehesht.php';
            break;
        case 'sabat.php':
            $breadcrumb['ساباط'] = $baseUrl . '/pages/sabat.php';
            break;
        case 'polaris.php':
            $breadcrumb['پلاریس'] = $baseUrl . '/pages/polaris.php';
            break;
        default:
            break;
        // می‌تونی صفحات دیگه‌ات رو هم اینجا اضافه کنی
    }
}
?>

<!-- نوار ناوبری -->
<header class="custom-header">
    <nav class="navbar navbar-expand-lg" dir="rtl">
        <div class="container-fluid container">

            <!-- لوگو و عنوان (سمت راست - شبیه‌سازی تصویر) -->
            <a class="navbar-brand d-flex align-items-center border-logo" href="<?= $baseUrl ?>/index.php">
                <img src="<?= $baseUrl ?>/images/logo.png" style="width: 120px;height: 120px" alt="لوگو" class="header-logo">
                <div class="logo-text">
                    <span class="top-text">سامانه مسکن سازان</span>
                    <span class="bottom-text">نقشه‌برداری</span>
                </div>
            </a>

            <!-- دکمه موبایل -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- منوها (بخش میانی) -->
            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <!-- صفحه اصلی -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='index.php'?'active':'' ?>" href="<?= $baseUrl ?>/index.php">صفحه اصلی</a>
                    </li>

                    <!-- معرفی گروه -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='groupIntroduction.php'?'active':'' ?>" href="<?= $baseUrl ?>/pages/groupIntroduction.php">معرفی گروه</a>
                    </li>

                    <!-- اهداف -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='goals.php'?'active':'' ?>" href="<?= $baseUrl ?>/pages/goals.php">اهداف</a>
                    </li>

                    <!-- دراپ‌داون پروژه‌ها -->
                    <li class="nav-item dropdown" >
                        <a class="nav-link dropdown-toggle" href="#" id="projectsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">پروژه‌ها</a>
                        <ul style="background-color: #1a237e" class="dropdown-menu shadow-sm" aria-labelledby="projectsDropdown">
                            <li ><a class="dropdown-item" href="<?= $baseUrl ?>/pages/garmdareh1.php">نقشه برداری ۱</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/garmdareh2.php">نقشه برداری ۲</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/toranj.php">ترنج</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/ordibehesht.php">اردیبهشت</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/polaris.php">پلاریس</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/sabat.php">ساباط</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/mehr.php">مهرآفرین</a></li>
                        </ul>
                    </li>

                    <!-- دراپ‌داون اعضا -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="membersDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">اعضا</a>
                        <ul class="dropdown-menu shadow-sm" aria-labelledby="membersDropdown">
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/groupmembers.php">ورود/ثبت نام عضو جدید</a></li>
                        </ul>
                    </li>

                    <!-- دراپ‌داون پیمانکاران -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="contractorsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">پیمانکاران/تامین‌کنندگان</a>
                        <ul class="dropdown-menu shadow-sm" aria-labelledby="contractorsDropdown">
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/peymankaran_taminkonandegan_login.php">ورود</a></li>
                        </ul>
                    </li>

                    <!-- بخش مدیریت (اصلاح شده به nav-link) -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='loginAdmin.php'?'active':'' ?>" href="/maskansazan/admin/loginAdmin.php">مدیریت</a>
                    </li>

                    <!-- ارتباط با ما (اصلاح شده به nav-link) -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='contact.php'?'active':'' ?>" href="/maskansazan/contact.php">ارتباط با ما</a>
                    </li>
                </ul>


                <!-- بخش سمت چپ (جستجو و تاریخ) -->
                <div class="header-left-side d-flex align-items-center">
                    <!-- دکمه جستجو که مودال را باز می‌کند -->
                    <a href="#" class="search-circle" data-bs-toggle="modal" data-bs-target="#searchModal">
                        <i class="fa fa-search text-white"></i>
                    </a>
                </div>

            </div>
        </div>
    </nav>
    <!-- اسلایدر -->
    <?php
    $slides = [
            ["نقشه برداری۱(گرمدره).jpg","پروژه نقشه برداری۱(گرمدره) ۱۳۹۴",""],
            ["نقشه برداری۲(گرمدره).jpg","پروژه نقشه برداری ۲(گرمدره)۱۳۹۵",""],
            ["ترنج(شهرک وحدت-نگارستان).jpg","پروژه ترنج(شهرک وحدت-نگارستان)۱۳۹۷",""],
            ["پلاریس(شهرک وحدت-نگارستان).jpg","پروژه پلاریس (شهرک وحدت-نگارستان) ۱۴۰۰",""],
            ["اردیبهشت(شهرک وحدت-نگارستان).jpg","پروژه اردیبهشت (شهرک وحدت-نگارستان) ۱۳۹۹",""],
            ["ساباط(شهرک وحدت نگارستان).jpg","پروژه ساباط (شهرک وحدت-نگارستان) ۱۴۰۱",""]
    ];

    $slideGroups = array_chunk($slides,3);
    ?>

    <div id="projectCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <div class="carousel-inner">

            <?php foreach($slideGroups as $index=>$group): ?>

                <div class="carousel-item <?= $index==0?'active':'' ?>">

                    <div class="container">
                        <div class="row g-4">

                            <?php foreach($group as $slide): ?>

                                <div class="col-lg-4 col-md-6">

                                    <div class="project-card">

                                        <div class="project-image">
                                            <img src="<?= $baseUrl ?>/images/<?= htmlspecialchars($slide[0]) ?>" class="img-fluid">
                                        </div>

                                        <div class="project-overlay">
                                            <h5><?= htmlspecialchars($slide[1]) ?></h5>
                                            <p><?= htmlspecialchars($slide[2]) ?></p>
                                        </div>

                                    </div>

                                </div>

                            <?php endforeach; ?>

                        </div>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#projectCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#projectCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>

    </div>
</header>


<ul class="breadcrumb">
    <?php foreach ($breadcrumb as $name => $link):
        $active = empty($link) || (basename($link) == $currentPage); ?>
        <li>
            <?php if (!$active && !empty($link)): ?>
                <a href="<?php echo htmlspecialchars($link); ?>"><?php echo htmlspecialchars($name); ?></a>
            <?php else: ?>
                <?php echo htmlspecialchars($name); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>
</ul>
<!-- اسکریپت تاریخ و زمان -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>
    if (typeof jQuery !== 'undefined') {
        jQuery.fn.carousel = function () {
            console.warn('Blocked legacy jQuery carousel call.');
            return this;
        };
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment-jalaali/0.9.4/moment-jalaali.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const carousel = document.getElementById('mainCarousel');
        const slideGroups = carousel.querySelectorAll('.slide-group');
        const prevBtn = carousel.querySelector('.slide-control.prev');
        const nextBtn = carousel.querySelector('.slide-control.next');
        const indicators = carousel.querySelectorAll('.slide-indicators button');

        let currentGroup = 0;
        let autoSlideInterval;
        const slideDuration = 5000; // 5 ثانیه

        // تابع نمایش گروه
        function showGroup(index) {
            if (index < 0 || index >= slideGroups.length) return;

            // مخفی کردن همه گروه‌ها
            slideGroups.forEach(group => {
                group.classList.remove('active');
            });

            // غیرفعال کردن همه نشانگرها
            indicators.forEach(indicator => {
                indicator.classList.remove('active');
            });

            // نمایش گروه جدید
            slideGroups[index].classList.add('active');
            indicators[index].classList.add('active');
            currentGroup = index;
        }

        // تابع بعدی
        function nextGroup() {
            const nextIndex = (currentGroup + 1) % slideGroups.length;
            showGroup(nextIndex);
        }

        // تابع قبلی
        function prevGroup() {
            const prevIndex = (currentGroup - 1 + slideGroups.length) % slideGroups.length;
            showGroup(prevIndex);
        }

        // شروع اسلاید اتوماتیک
        function startAutoSlide() {
            stopAutoSlide();
            autoSlideInterval = setInterval(nextGroup, slideDuration);
        }

        // توقف اسلاید اتوماتیک
        function stopAutoSlide() {
            if (autoSlideInterval) {
                clearInterval(autoSlideInterval);
                autoSlideInterval = null;
            }
        }

        // افزودن رویدادها به دکمه‌ها
        prevBtn.addEventListener('click', function() {
            prevGroup();
            stopAutoSlide();
            startAutoSlide();
        });

        nextBtn.addEventListener('click', function() {
            nextGroup();
            stopAutoSlide();
            startAutoSlide();
        });

        // افزودن رویدادها به نشانگرها
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', function() {
                showGroup(index);
                stopAutoSlide();
                startAutoSlide();
            });
        });

        // مدیریت رویدادهای کیبورد
        carousel.addEventListener('keydown', function(e) {
            if (e.target.matches('.slide-control, .slide-indicators button')) {
                return;
            }

            switch(e.key) {
                case 'ArrowRight':
                case 'Right':
                    e.preventDefault();
                    prevGroup();
                    stopAutoSlide();
                    startAutoSlide();
                    break;
                case 'ArrowLeft':
                case 'Left':
                    e.preventDefault();
                    nextGroup();
                    stopAutoSlide();
                    startAutoSlide();
                    break;
                case 'Home':
                    e.preventDefault();
                    showGroup(0);
                    stopAutoSlide();
                    startAutoSlide();
                    break;
                case 'End':
                    e.preventDefault();
                    showGroup(slideGroups.length - 1);
                    stopAutoSlide();
                    startAutoSlide();
                    break;
            }
        });

        // توقف اسلاید هنگام hover
        carousel.addEventListener('mouseenter', stopAutoSlide);
        carousel.addEventListener('mouseleave', startAutoSlide);

        // توقف اسلاید هنگام focus روی عناصر
        carousel.addEventListener('focusin', stopAutoSlide);
        carousel.addEventListener('focusout', function(e) {
            if (!carousel.contains(e.relatedTarget)) {
                startAutoSlide();
            }
        });

        // راه‌اندازی اولیه
        showGroup(0);
        startAutoSlide();

        // مدیریت تغییر سایز صفحه
        let resizeTimer;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                // می‌توانید کدهای مربوط به تغییر سایز را اینجا قرار دهید
                console.log('سایز صفحه تغییر کرد');
            }, 250);
        });

        // لودینگ بهتر تصاویر
        const images = carousel.querySelectorAll('img');
        images.forEach(img => {
            if (img.complete) {
                img.style.opacity = '1';
            } else {
                img.style.opacity = '0';
                img.addEventListener('load', function() {
                    this.style.transition = 'opacity 0.5s ease';
                    this.style.opacity = '1';
                });
            }
        });
    });
    function updateDateTime() {
        const now = new Date();

        const persianDate = moment(now).format('jYYYY/jMM/jDD');
        const gregorianDate = now.toLocaleDateString('en-US', {
            year: 'numeric', month: 'short', day: 'numeric'
        });
        const localTime = now.toLocaleTimeString('fa-IR', {
            hour: '2-digit', minute: '2-digit', second: '2-digit'
        });

        document.getElementById('persian-date').textContent = "شمسی: " + persianDate;
        document.getElementById('gregorian-date').textContent = "میلادی: " + gregorianDate;
        document.getElementById('local-time').textContent = "🕒 " + localTime;

        setTimeout(updateDateTime, 1000);
    }
    updateDateTime();

</script>

<!-- استایل واکنش‌گرا -->
<style>
    @media (max-width: 991px) {
        #datetime-box {
            order: 1 !important;
            font-size: 12px;
            margin-top: 6px;
            background: linear-gradient(135deg, #10b981, #2563eb);
        }
    }
</style>
