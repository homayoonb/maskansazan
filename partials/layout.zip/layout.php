<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// مسیر پروژه (اگر در روت هست خالی بگذار)
$baseUrl = '/maskansazan';

$currentPage = basename($_SERVER['PHP_SELF']);
$projectPages = [
        'mehr.php' => 'مهرآفرین',
        'toranj.php' => 'ترنج',
        'garmdareh1.php' => 'نقشه‌برداری ۱',
        'garmdareh2.php' => 'نقشه‌برداری ۲',
        'ordibehesht.php' => 'اردیبهشت',
        'sabat.php' => 'ساباط',
        'polaris.php' => 'پلاریس'
];

// مسیر پایه همیشه صفحه اصلی است
$breadcrumb = [
        'صفحه اصلی' => $baseUrl . '/index.php'
];

// اگر صفحه فعلی جزو پروژه‌ها باشد
if (array_key_exists($currentPage, $projectPages)) {
    $breadcrumb['پروژه‌ها'] = ''; // بدون لینک
    $breadcrumb[$projectPages[$currentPage]] = $baseUrl . '/pages/' . $currentPage;
}
// در غیر این صورت، صفحات معمولی
else {
    switch ($currentPage) {
        case 'goals.php':
            $breadcrumb['اهداف'] = $baseUrl . '/pages/goals.php';
            break;
        case 'groupIntroduction.php':
            $breadcrumb['معرفی گروه'] = $baseUrl . '/pages/groupIntroduction.php';
            break;
        case 'garmdareh1.php':
            $breadcrumb['نقشه برداری ۱'] = $baseUrl . '/pages/garmdareh1.php';
            break;
        case 'garmdareh2.php':
            $breadcrumb['نقشه برداری 2'] = $baseUrl . '/pages/garmdareh2.php';
            break;
        case 'ordibehesht.php':
            $breadcrumb['اردیبهشت']= $baseUrl . '/pages/ordibehesht.php';
            break;
        case 'sabat.php':
            $breadcrumb['ساباط'] = $baseUrl . '/pages/sabat.php';
            break;
        case 'polaris.php':
            $breadcrumb['پلاریس'] = $baseUrl . '/pages/polaris.php';
            break;
        default:
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($title) ? htmlspecialchars($title) : 'سامانه مسکن سازان'; ?></title>

    <!-- CSS ها -->
    <link rel="stylesheet" href="<?= $baseUrl ?>/lib/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/css/site.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/fontsource/vazir/all.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/vazir-font@29.1.0/dist/font-face.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- بارگذاری فونت ایران نستعلیق -->
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/iran-nastaliq-font@latest/dist/iran-nastaliq.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
     <style>
        @import url('https://cdn.jsdelivr.net/font-face/vazirmatn/vazirmatn-font-face.css');

        #mainCarousel { transition: all 0.8s ease-in-out; overflow: hidden; }
        #mainCarousel.hidden { opacity:0; height:0; transform:scale(0.8); pointer-events:none; }

        #loginButton { position:absolute; top:20px; right:20px; z-index:1000; padding:12px 24px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color:white; border:none; border-radius:25px; cursor:pointer;
            font-family:'Vazir', sans-serif; font-size:16px; font-weight:bold;
            box-shadow:0 4px 15px rgba(0,0,0,0.2); transition: all 0.3s ease;}
        #loginButton:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(0,0,0,0.3); }

        #mainContent { display:none; opacity:0; transition: opacity 0.8s ease; }
        #mainContent.visible { display:block; opacity:1; }

        ul.breadcrumb {
            padding: 10px 16px;
            list-style: none;
            background-color: #eee;
            border-radius: 8px;
            font-family: "Tahoma", sans-serif;
            margin: 10px 0;
        }
        ul.breadcrumb li {
            display: inline;
            font-size: 16px;
            color: #555;
        }
        ul.breadcrumb li+li:before {
            padding: 8px;
            color: #555;
            content: "/\00a0";
        }
        ul.breadcrumb li a {
            color: #0275d8;
            text-decoration: none;
            transition: color 0.2s;
        }
        ul.breadcrumb li a:hover {
            color: #01447e;
            text-decoration: underline;
        }
        ul.breadcrumb li:last-child {
            font-weight: bold;
            color: #000;
        }
        @media (max-width: 768px) {
            ul.breadcrumb {
                font-size: 14px;
                padding: 8px 10px;
            }
        }

        /* موبایل: منو راست، زیرمنوها راست‌چین */


        /* دسکتاپ: زیرمنوها با hover باز شوند */
        @media (min-width:992px){
            .navbar .dropdown:hover .dropdown-menu { display:block; }
        }
/* ===== استایل اصلی اسلایدر ===== */
.carousel-fade-container {
    position: relative;
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: #fff;
}

.carousel-wrapper {
    position: relative;
    width: 100%;
    height: 500px;
    overflow: hidden;
}

/* ===== گروه اسلایدها ===== */
.slide-group {
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 100%;
    display: flex;
    opacity: 0;
    transform: translateX(50px);
    transition: opacity 0.6s ease, transform 0.6s ease;
    pointer-events: none;
    padding: 30px;
    gap: 20px;
}

.slide-group.active {
    opacity: 1;
    transform: translateX(0);
    pointer-events: all;
}

/* ===== کانتینر اسلایدها ===== */
.slides-container {
    display: flex;
    width: 100%;
    height: 100%;
    gap: 20px;
}

/* ===== هر اسلاید مجزا ===== */
.slide-item {
    flex: 1;
    position: relative;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    background: #fff;
    min-width: 0;
}

.slide-item:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
    z-index: 10;
}

.slide-image {
    position: relative;
    width: 100%;
    height: 70%;
    overflow: hidden;
}

.slide-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.8s ease;
}

.slide-item:hover .slide-image img {
    transform: scale(1.1);
}

.slide-overlay {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 100%;
    height: 50%;
    background: linear-gradient(to top,
        rgba(0, 0, 0, 0.9) 0%,
        rgba(0, 0, 0, 0.5) 50%,
        transparent 100%);
    z-index: 1;
}

.slide-content {
    position: absolute;
    bottom: 0;
    right: 0;
    left: 0;
    padding: 25px;
    color: white;
    z-index: 2;
    text-align: right;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(5px);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.slide-content h3 {
    font-size: 1.3rem;
    margin-bottom: 10px;
    font-weight: 600;
    color: #fff;
}

.slide-content p {
    font-size: 0.9rem;
    opacity: 0.9;
    line-height: 1.6;
    margin-bottom: 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

/* ===== شماره گروه ===== */
.group-number {
    position: absolute;
    top: 20px;
    left: 20px;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 500;
    z-index: 10;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
}

/* ===== دکمه‌های کنترل ===== */
.slide-control {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 50px;
    height: 50px;
    background: rgba(255, 255, 255, 0.9);
    border: none;
    border-radius: 50%;
    color: #333;
    font-size: 1.2rem;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: center;
}

.slide-control:hover {
    background: #2c3e50;
    color: white;
    transform: translateY(-50%) scale(1.1);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
}

.slide-control.prev {
    right: 20px;
}

.slide-control.next {
    left: 20px;
}

/* ===== نشانگرها ===== */
.slide-indicators {
    position: absolute;
    bottom: 20px;
    right: 50%;
    transform: translateX(50%);
    display: flex;
    gap: 10px;
    z-index: 100;
}

.slide-indicators button {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 2px solid rgba(255, 255, 255, 0.7);
    background: transparent;
    cursor: pointer;
    transition: all 0.3s ease;
    padding: 0;
}

.slide-indicators button:hover {
    background: rgba(255, 255, 255, 0.5);
    transform: scale(1.2);
}

.slide-indicators button.active {
    background: white;
    border-color: white;
    transform: scale(1.3);
    box-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
}

/* ===== انیمیشن‌ها ===== */
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(30px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.slide-group.active {
    animation: slideIn 0.6s ease forwards;
}

/* ===== رسپانسیو ===== */
@media (max-width: 1200px) {
    .carousel-fade-container {
        max-width: 95%;
    }

    .carousel-wrapper {
        height: 450px;
    }
}

@media (max-width: 992px) {
    .carousel-wrapper {
        height: 400px;
    }

    .slides-container {
        gap: 15px;
    }

    .slide-content {
        padding: 20px;
    }

    .slide-content h3 {
        font-size: 1.2rem;
    }
}

@media (max-width: 768px) {
    .carousel-wrapper {
        height: 350px;
    }

    .slide-group {
        flex-direction: column;
        padding: 20px;
        gap: 15px;
    }

    .slides-container {
        flex-direction: column;
        height: auto;
    }

    .slide-item {
        height: 220px;
    }

    .slide-image {
        height: 65%;
    }

    .slide-control {
        width: 40px;
        height: 40px;
        font-size: 1rem;
    }

    .slide-control.prev {
        right: 15px;
    }

    .slide-control.next {
        left: 15px;
    }

    .group-number {
        top: 15px;
        left: 15px;
        font-size: 0.85rem;
        padding: 6px 14px;
    }
}

@media (max-width: 576px) {
    .carousel-wrapper {
        height: 300px;
    }

    .slide-item {
        height: 180px;
    }

    .slide-content {
        padding: 15px;
    }

    .slide-content h3 {
        font-size: 1.1rem;
    }

    .slide-content p {
        font-size: 0.85rem;
        -webkit-line-clamp: 1;
    }

    .slide-indicators {
        bottom: 15px;
    }
}

/* ===== استایل برای تعداد کم اسلایدها ===== */
.slides-container:has(.slide-item:only-child) {
    justify-content: center;
}

.slides-container:has(.slide-item:only-child) .slide-item {
    max-width: 600px;
}

/* ===== افکت‌های اضافی ===== */
.slide-item::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg,
        rgba(44, 62, 80, 0.1) 0%,
        transparent 50%);
    z-index: 1;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.slide-item:hover::before {
    opacity: 1;
}

/* ===== بهبود focus ===== */
.slide-control:focus,
.slide-indicators button:focus,
.slide-item:focus {
    outline: 2px solid #2c3e50;
    outline-offset: 2px;
}
/* استایل برای عنوان بالای منو */
.site-title-bar {
    background: linear-gradient(135deg, #36d1dc 0%, #5b86e5 100%);
    color: white;
    text-align: center;
    padding: 25px 15px;
    font-size: 40px; /* سایز بزرگتر برای نستعلیق */
    font-weight: normal; /* وزن معمولی برای نستعلیق */
    font-family: 'IranNastaliq', 'Iran Nastaliq', 'Vazirmatn', 'Vazir', Tahoma, sans-serif;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
    position: relative;
    z-index: 1001;
    letter-spacing: 0; /* فاصله بین حروف برای نستعلیق صفر باشد */
    line-height: 1.8; /* ارتفاع خط بیشتر برای خوانایی بهتر */
    border-bottom: 3px solid #1abc9c;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
    direction: rtl; /* راست به چپ برای نستعلیق */
}

/* تنظیمات خاص برای نمایش بهتر نستعلیق */
.site-title-bar::before {
    content: '';
    position: absolute;
    top: 10px;
    right: 10px;
    width: 30px;
    height: 30px;

    opacity: 0.7;
}

/* برای صفحات موبایل */
@media (max-width: 768px) {
    .site-title-bar {
        font-size: 28px; /* سایز کوچکتر برای موبایل */
        padding: 20px 10px;
        line-height: 1.6;
    }
}

/* برای صفحات تبلت */
@media (max-width: 992px) {
    .site-title-bar {
        font-size: 32px;
        padding: 22px 12px;
        line-height: 1.7;
    }
}

/* برای حالت چاپ */
@media print {
    .site-title-bar {
        font-family: 'IranNastaliq', 'Times New Roman', serif;
        color: black;
        background: none;
        box-shadow: none;
        border-bottom: 2px solid #333;
    }
}

/* انیمیشن برای عنوان */
.site-title-bar {
    animation: fadeInDown 0.8s ease-out;
}

@keyframes fadeInDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* جلوگیری از انتخاب متن (اختیاری) */
.site-title-bar {
    user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
}

/* افکت hover اختیاری */
.site-title-bar:hover {
    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.4);
    transform: translateY(-2px);
    transition: all 0.3s ease;
}
        .site-title-bar {
            background: linear-gradient(90deg, #1cb5e0 0%, #000851 100%);
            padding: 10px 0;
            color: white;
            font-size: 22px;
            font-weight: bold;
        }

        .site-logo {
            height: 55px;   /* تنظیم اندازه لوگو */
            width: auto;
            object-fit: contain;
        }
        /* استایل کلی هدر مطابق تصویر */
        .site-header {
            background-color: #e4f8fc !important; /* رنگ آبی روشن پس‌زمینه */
            border-bottom: 2px solid #d0e7ed;
        }

        .navbar {
            padding: 15px 0 !important;
            background-color: transparent !important; /* حذف رنگ مشکی قبلی */
        }

        /* استایل لوگو شبیه تصویر (باکس‌دار) */
        .border-logo {
            border: 1px solid #1a2d50;
            padding: 5px 15px;
            background: white;
            text-decoration: none;
        }

        .header-logo {
            height: 60px;
            width: auto;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
            margin-right: 10px;
            color: #1a2d50;
            font-weight: bold;
            border-right: 2px solid #1a2d50;
            padding-right: 10px;
        }

        .top-text { font-size: 14px; }
        .bottom-text { font-size: 18px; color: #f9b115; /* رنگ نارنجی/زرد مشابه بینش */ }

        /* استایل منوها */
        .navbar-nav .nav-link {
            color: #1a2d50 !important; /* رنگ سرمه‌ای تیره */
            font-weight: 600;
            font-size: 15px;
            margin: 0 10px;
        }

        .navbar-nav .nav-link:hover, .navbar-nav .nav-link.active {
            color: #0056b3 !important;
        }

        /* آیکون جستجوی دایره‌ای سمت چپ */
        .search-circle {
            background-color: #1a2d50;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        /* اصلاح نمایش در موبایل */
        @media (max-width: 991px) {
            .logo-text { display: none; }
            .header-left-side { margin-top: 15px; justify-content: center; }
        }
        /* ===============================
           ✅ HEADER FINAL CLEAN VERSION
        =================================*/

        .site-header {
            background-color: #e4f8fc;
            border-bottom: 2px solid #d0e7ed;
        }

        .navbar {
            padding: 15px 0 !important;
            background: transparent !important;
        }

        /* لوگو باکس‌دار */
        .border-logo {
            border: 1px solid #1a2d50;
            background: #fff;
            padding: 6px 15px;
            border-radius: 4px;
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .header-logo {
            height: 60px;
            width: auto;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
            margin-right: 12px;
            padding-right: 12px;
            border-right: 2px solid #1a2d50;
            color: #1a2d50;
            font-weight: bold;
            line-height: 1.3;
        }

        .top-text {
            font-size: 14px;
        }

        .bottom-text {
            font-size: 18px;
            color: #f9b115;
        }

        /* منوها */
        .navbar-nav .nav-link {
            color: #1a2d50 !important;
            font-weight: 600;
            font-size: 15px;
            padding: 8px 15px !important;
        }

        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #0056b3 !important;
        }

        /* آیکون جستجو */
        .search-circle {
            background-color: #0d2a5e;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: 0.3s;
        }

        .search-circle:hover {
            background-color: #1a4da1;
            transform: scale(1.1);
        }

        /* موبایل */
        @media (max-width: 991px) {

            .logo-text {
                display: none;
            }

            .header-left-side {
                margin-top: 15px;
                justify-content: center;
            }

            .navbar-toggler {
                border-color: #1a2d50 !important;
            }

            .navbar-toggler-icon {
                filter: invert(20%);
            }
        }
        /* استایل سفارشی مودال جستجو */
        #searchModal .modal-content {
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        #searchModal .form-control {
            border: 2px solid #1a2d50;
            border-radius: 0 8px 8px 0 !important; /* لبه‌های گرد سمت راست برای فارسی */
        }

        #searchModal .btn-warning {
            background-color: #f1ad1d;
            border-color: #f1ad1d;
            color: #1a2d50;
            font-weight: bold;
            border-radius: 8px 0 0 8px !important; /* لبه‌های گرد سمت چپ */
        }

        #searchModal .btn-warning:hover {
            background-color: #d49615;
            color: #fff;
        }

        /* افکت محو شدن پشت زمینه */
        .modal-backdrop.show {
            opacity: 0.7;
            backdrop-filter: blur(5px); /* ایجاد حالت شیشه‌ای برای پشت صفحه */
        }
        /* استایل کلی منوهای اصلی */
        .navbar-nav .nav-link {
            color: #1a2d50 !important; /* رنگ سرمه‌ای */
            font-weight: 600;
            padding: 10px 15px !important;
            transition: 0.3s;
        }

        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #f1ad1d !important; /* تغییر رنگ به طلایی هنگام هاور */
        }

        /* استایل زیرمنوها (Dropdown) */
        .dropdown-menu {
            border: none;
            border-top: 3px solid #f1ad1d; /* خط طلایی بالای باکس زیرمنو */
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-radius: 0 0 8px 8px;
            padding: 10px 0;
            text-align: right; /* راست‌چین برای زبان فارسی */
        }

        .dropdown-item {
            color: #1a2d50;
            font-size: 14px;
            padding: 8px 20px;
            background-color: white;
        }

        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #f1ad1d;
            padding-right: 25px; /* افکت جابجایی ملایم */
        }

        /* نمایش زیرمنو با هاور (اختیاری - اگر دوست دارید با نگه داشتن موس باز شود) */
        @media (min-width: 992px) {
            .nav-item.dropdown:hover .dropdown-menu {
                display: block;
                margin-top: 0;
            }
        }
        .project-card{
            position:relative;
            overflow:hidden;
            border-radius:12px;
            box-shadow:0 10px 25px rgba(0,0,0,.08);
            transition:.4s;
        }

        .project-card:hover{
            transform:translateY(-8px);
            box-shadow:0 20px 40px rgba(0,0,0,.15);
        }

        .project-image img{
            height:240px;
            width:100%;
            object-fit:cover;
            transition:.6s;
        }

        .project-card:hover img{
            transform:scale(1.08);
        }

        .project-overlay{
            position:absolute;
            bottom:0;
            left:0;
            right:0;
            padding:20px;
            background:linear-gradient(to top,rgba(0,0,0,.75),transparent);
            color:#fff;
        }

        .project-overlay h5{
            font-size:16px;
            font-weight:700;
        }

        .project-overlay p{
            font-size:13px;
        }

        /* دکمه‌های اسلایدر */
        .carousel-control-prev-icon,
        .carousel-control-next-icon{
            background-color:#1a2d50;
            padding:18px;
            border-radius:50%;
        }

        .carousel-control-prev-icon:hover,
        .carousel-control-next-icon:hover{
            background:#f1ad1d;
        }

     </style>

</head>
<body>
<header class="site-header">
    <nav class="navbar navbar-expand-lg" dir="rtl">
        <div class="container-fluid container">

            <!-- لوگو و عنوان (سمت راست - شبیه‌سازی تصویر) -->
            <a style="background-color: #E4F8FC" class="navbar-brand d-flex align-items-center" href="<?= $baseUrl ?>/index.php">
                <img src="<?= $baseUrl ?>/images/logo.png" style="width: 120px;height: 120px" alt="لوگو" class="header-logo">
                <div class="logo-text">
                    <span class="top-text">گروه مسکن سازان</span>
                    <span class="bottom-text">نقشه‌برداری</span>
                </div>
            </a>

            <!-- دکمه موبایل -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- منوها (بخش میانی) -->
            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <!-- صفحه اصلی -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='index.php'?'active':'' ?>" href="<?= $baseUrl ?>/index.php">صفحه اصلی</a>
                    </li>

                    <!-- معرفی گروه -->
<!--                    <li class="nav-item">-->
<!--                        <a class="nav-link --><?php //= $currentPage=='groupIntroduction.php'?'active':'' ?><!--" href="--><?php //= $baseUrl ?><!--/pages/groupIntroduction.php">معرفی گروه</a>-->
<!--                    </li>-->

                    <!-- اهداف -->
<!--                    <li class="nav-item">-->
<!--                        <a class="nav-link --><?php //= $currentPage=='goals.php'?'active':'' ?><!--" href="--><?php //= $baseUrl ?><!--/pages/goals.php">اهداف</a>-->
<!--                    </li>-->

                    <!-- دراپ‌داون پروژه‌ها -->
                    <li class="nav-item dropdown" >
                        <a class="nav-link dropdown-toggle" href="#" id="projectsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">پروژه‌ها</a>
                        <ul style="background-color: #1a237e" class="dropdown-menu shadow-sm" aria-labelledby="projectsDropdown">
                            <li ><a class="dropdown-item" href="<?= $baseUrl ?>/pages/garmdareh1.php">نقشه برداری ۱</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/garmdareh2.php">نقشه برداری ۲</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/toranj.php">ترنج</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/ordibehesht.php">اردیبهشت</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/polaris.php">پلاریس</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/sabat.php">ساباط</a></li>
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/pages/mehr.php">مهرآفرین</a></li>
                        </ul>
                    </li>

                    <!-- دراپ‌داون اعضا -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="membersDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">اعضا</a>
                        <ul class="dropdown-menu shadow-sm" aria-labelledby="membersDropdown">
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/groupmembers.php">ورود/ثبت نام عضو جدید</a></li>
                        </ul>
                    </li>

                    <!-- دراپ‌داون پیمانکاران -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="contractorsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">پیمانکاران/تامین‌کنندگان</a>
                        <ul class="dropdown-menu shadow-sm" aria-labelledby="contractorsDropdown">
                            <li><a class="dropdown-item" href="<?= $baseUrl ?>/peymankaran_taminkonandegan_login.php">ورود</a></li>
                        </ul>
                    </li>

                    <!-- بخش مدیریت (اصلاح شده به nav-link) -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='loginAdmin.php'?'active':'' ?>" href="/maskansazan/admin/loginAdmin.php">مدیریت</a>
                    </li>

                    <!-- ارتباط با ما (اصلاح شده به nav-link) -->
                    <li class="nav-item">
                        <a class="nav-link <?= $currentPage=='contact.php'?'active':'' ?>" href="/maskansazan/contact.php">ارتباط با ما</a>
                    </li>
                </ul>


                <!-- بخش سمت چپ (جستجو و تاریخ) -->
                <div class="header-left-side d-flex align-items-center">
                    <!-- دکمه جستجو که مودال را باز می‌کند -->
                    <a href="#" class="search-circle" data-bs-toggle="modal" data-bs-target="#searchModal">
                        <i class="fa fa-search text-white"></i>
                    </a>
                </div>

            </div>
        </div>
    </nav>

    <!-- نوار مسیر (Breadcrumb) -->
    <div class="container">
        <ul class="breadcrumb" style="background-color: #E4F8FC">
            <?php foreach ($breadcrumb as $name => $link):
                $active = empty($link) || (basename($link) == $currentPage); ?>
                <li>
                    <?php if (!$active && !empty($link)): ?>
                        <a href="<?= htmlspecialchars($link); ?>"><?= htmlspecialchars($name); ?></a>
                    <?php else: ?>
                        <?= htmlspecialchars($name); ?>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</header>




<!-- محتوای صفحات -->
<main class="container py-4">
    <?php echo isset($content)?$content:''; ?>
</main>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // فقط در صفحه اصلی site.js کامل را بارگیری کن
    <?php if ($currentPage == 'index.php'): ?>
    setTimeout(function() {
        var script = document.createElement('script');
        script.src = '<?= $baseUrl ?>/js/site.js';
        script.onload = function() {
            console.log('site.js با موفقیت بارگیری شد');
        };
        script.onerror = function() {
            console.error('خطا در بارگیری site.js');
        };
        document.body.appendChild(script);
    }, 800);
    <?php else: ?>
    setTimeout(function() {
        if (typeof jQuery !== 'undefined') {
            jQuery(function($) {
                if ($(window).width() < 992) {
                    $('.dropdown-toggle').on('click', function(e) {
                        e.preventDefault();
                        $(this).next('.dropdown-menu').toggleClass('show');
                    });

                    $(document).on('click', function(e) {
                        if (!$(e.target).closest('.dropdown').length) {
                            $('.dropdown-menu').removeClass('show');
                        }
                    });
                } else {
                    $('.navbar .dropdown').hover(
                        function() { $(this).addClass('show').find('.dropdown-menu').addClass('show'); },
                        function() { $(this).removeClass('show').find('.dropdown-menu').removeClass('show'); }
                    );
                }
            });
        }
    }, 300);
    <?php endif; ?>
</script>



<?php if(isset($extraScripts)) echo $extraScripts; ?>
<!-- Modal Search -->
<div class="modal fade" id="searchModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" style="border-radius: 15px; border: none; overflow: hidden;">
            <div class="modal-header" style="background-color: #1a2d50; color: white;">
                <h5 class="modal-title">جستجو در سامانه</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding: 30px; background: #f8f9fa;">
                <form action="search.php" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" name="q" class="form-control form-control-lg text-end" placeholder="عبارت مورد نظر را بنویسید..." autofocus>
                        <button class="btn btn-warning px-4" type="submit">
                            <i class="fa fa-search"></i> جستجو
                        </button>
                    </div>
                    <div class="text-muted small">
                        مثلاً: پروژه‌های مسکونی، اعضای هیئت مدیره و...
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>
