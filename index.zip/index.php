<?php
include 'partials/layout.php';
include 'partials/slider.php';
?>

<!-- استایل‌های اختصاصی صفحه سابقه فعالیت -->
<style>
    .about-body {
        background-color: #f8f9fa;
        color: #333;
    }
    .hero-section {
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        color: white;
        padding: 60px 0;
        margin-bottom: 50px;
        border-bottom-right-radius: 50px;
        border-bottom-left-radius: 50px;
    }
    .card-custom {
        border: none;
        border-radius: 15px;
        transition: transform 0.3s ease;
        box-shadow: 0 10px 20px rgba(0,0,0,0.05);
        background: #fff;
    }
    .card-custom:hover {
        transform: translateY(-10px);
    }
    .icon-box {
        width: 70px;
        height: 70px;
        background-color: #e4f8fc;
        color: #0d6efd;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
        margin-bottom: 20px;
    }
    .stat-card {
        background-color: #fff;
        padding: 25px;
        text-align: center;
        border-right: 5px solid #0d6efd;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .principle-title {
        color: #1e3c72;
        font-weight: bold;
    }
    .timeline-badge {
        background: #ffc107;
        color: #000;
        padding: 5px 15px;
        border-radius: 20px;
        font-weight: bold;
    }
    .about-logo {
        max-width: 350px;
        background-color: #e4f8fc;
        padding: 20px;
        border-radius: 50%;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1);
    }
</style>

<div class="about-body">
    <!-- Header Section -->
    <header class="hero-section text-center">
        <div class="container">
            <h1 class="display-5 fw-bold mb-3">سابقه فعالیت و افتخارات</h1>
            <p class="lead text-light">گروه مهندسان مسکن‌ساز نقشه‌برداری - از سال ۱۳۹۲ تا امروز</p>
        </div>
    </header>

    <main class="container">
        <!-- History Section -->
        <section class="row mb-5 align-items-center">
            <div class="col-lg-7 order-2 order-lg-1">
                <span class="timeline-badge mb-3 d-inline-block small">تأسیس: ۱۳۹۲</span>
                <h2 class="mb-4 fw-bold">داستان شکل‌گیری گروه</h2>
                <p class="lh-lg text-secondary text-justify">
                    این گروه با هدف تولید مسکن برای کارکنان سازمان نقشه‌برداری کشور فعالیت خود را آغاز کرد.
                    هیات امنای سه نفره هدایت این مسیر را بر عهده گرفت و با احداث اولین پروژه ۳۵ واحدی با نام "نقشه‌برداری ۱" در گرمدره کرج، گام اول را استوار برداشت.
                    با افزایش اعتماد و تقاضا، پروژه‌های بعدی نیز یکی پس از دیگری آغاز گردید.
                </p>

                <div class="row mt-4 g-3">
                    <div class="col-6 col-md-4">
                        <div class="stat-card">
                            <h3 class="fw-bold text-primary">۳۰۵+</h3>
                            <p class="text-muted mb-0 small">واحد مسکونی</p>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="stat-card">
                            <h3 class="fw-bold text-primary">۶</h3>
                            <p class="text-muted mb-0 small">پروژه موفق</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Principles Section -->
        <section class="py-5">
            <div class="text-center mb-5">
                <h2 class="fw-bold">دیدگاه‌ها و اصول بنیادی</h2>
                <div class="mx-auto" style="width: 60px; height: 3px; background: #0d6efd;"></div>
            </div>

            <div class="row g-4">
                <!-- Principle 1 -->
                <div class="col-md-4">
                    <div class="card-custom h-100 p-4">
                        <div class="icon-box">
                            <i class="fas fa-users-cog"></i>
                        </div>
                        <h4 class="principle-title h5">حقوق اعضا</h4>
                        <p class="text-muted small lh-base">در همه حال حق با اعضاء بوده؛ ما پس از گزارش‌دهی و مشاوره تخصصی، به رای اعضاء احترام گذاشته و صرفاً مجری راهکارهای انتخابی هستیم.</p>
                    </div>
                </div>
                <!-- Principle 2 -->
                <div class="col-md-4">
                    <div class="card-custom h-100 p-4">
                        <div class="icon-box">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h4 class="principle-title h5">شفافیت اسناد</h4>
                        <p class="text-muted small lh-base">شفاف‌سازی در مستندات حق مسلم اعضاء است. ثبت سند به نام افراد از همان ابتدا به عنوان یک اصل حقوقی غیرقابل تغییر رعایت می‌شود.</p>
                    </div>
                </div>
                <!-- Principle 3 -->
                <div class="col-md-4">
                    <div class="card-custom h-100 p-4">
                        <div class="icon-box">
                            <i class="fas fa-check-double"></i>
                        </div>
                        <h4 class="principle-title h5">کیفیت و اصول</h4>
                        <p class="text-muted small lh-base">سودرسانی به اعضاء هدف ماست، اما هرگز کیفیت را فدای هزینه نمی‌کنیم. تمامی استانداردها و دستورالعمل‌های نظام مهندسی در اولویت هستند.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<?php
include 'partials/footer.php';
?>
