<?php
$images = ["1.jpg","2.jpg","4.jpg"];
$images2 = ["Picture3.jpg","Picture4.jpg","Picture5.jpg"];

$title = "موقعیت مکانی پروژه نقشه برداری ۲";
$latitude = "35.74939035365549";
$longitude = "51.060020271164355";

include "../partials/layout.php";
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $title ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        html, body { height: 100%; }
        body{
            margin:0;
            font-family: Tahoma, Arial, sans-serif;
            background:#f5f5f5;

            /* sticky footer */
            min-height: 100vh;
            display:flex;
            flex-direction:column;
        }
        main{ flex:1; }

        :root {
            --primary: #5ec9f3;
            --border: #dcdcdc;
            --bg-soft: #f7f9fc;
            --text-main: #222;
            --text-muted: #666;
        }

        .font-vazir { font-family: 'Tahoma', sans-serif; }
        .card-header { background: linear-gradient(135deg, #1a1a1a 0%, #373b3e 100%); }

        .btn-check:checked + .btn { background-color: #0d6efd !important; color: white !important; }
        .border-start { border-color: #dee2e6 !important; }

        @media (max-width: 768px) {
            .border-start { border-left: none !important; border-bottom: 1px solid #dee2e6; padding-bottom: 10px; }
        }
    </style>
</head>

<body>

    <!-- فقط یک container، و همه چیز داخلش -->
    <div class="container my-5">
        <div class="container my-5 font-vazir" dir="rtl">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden mb-4">
                <div class="card-header bg-dark p-4 d-flex justify-content-between align-items-center border-0">
                    <div>
                        <h2 class="h4 text-white fw-bold mb-1">پروژه نقشه برداری۲</h2>
                        <small class="text-white-50">واقع در بلوار امیرکبیر
                        </small>
                    </div>
                    <div class="text-start">
                        <span class="badge bg-primary px-3 py-2 rounded-pill">شروع:۱۳۹۳/۰۳/۰۱</span>
                    </div>
                </div>

                <div class="card-body p-4 p-md-5">
                    <h5 class="fw-bold mb-3 d-flex align-items-center">
                        <span class="bg-primary p-1 rounded me-2" style="width: 10px; height: 25px; display: inline-block;"></span>
                        مشخصات پروژه
                    </h5>
                    <div class="row g-3 mb-5">
                        <div class="col-6 col-md-3 text-center border-start">
                            <div class="text-muted small mb-1">متراژ زمین (متر مربع)
                            </div>
                            <div class="h5 fw-bold text-primary">۱,۰۰۰</div>
                        </div>
                        <div class="col-6 col-md-3 text-center border-start">
                            <div class="text-muted small mb-1">تعداد واحد مسکونی ساخته شده</div>
                            <div class="h5 fw-bold text-primary">۳۵</div>
                        </div>
                        <div class="col-6 col-md-3 text-center border-start">
                            <div class="text-muted small mb-1">تعداد طبقات</div>
                            <div class="h5 fw-bold text-primary">۹ </div>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <div class="text-muted small mb-1">تعداد واحد تجاری ساخته شده</div>
                            <div class="h5 fw-bold text-primary">۲ </div>
                        </div>
                    </div>

                    <div class="mb-5">
                        <h5 class="fw-bold mb-3 d-flex align-items-center">
                            <span class="bg-primary p-1 rounded me-2" style="width: 10px; height: 25px; display: inline-block;"></span>
                            جزئیات ساخت و تعهدات
                        </h5>
                        <div class="table-responsive rounded-3 border">
                            <table class="table table-hover align-middle mb-0 text-center">
                                <thead class="bg-light">
                                <tr>
                                    <th class="py-3">تعهدات اولیه</th>
                                    <th class="py-3">متراژ هر واحد</th>
                                    <th class="py-3">مجموع متراژ تجاری</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>30 واحد 75 متری</td>
                                    <td class="fw-bold text-secondary">۸۶ </td>
                                    <td>۱۰۰ </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="bg-light rounded-4 p-4 border-0">
                        <h5 class="fw-bold mb-4 d-flex align-items-center text-success">
                            <i class="fas fa-coins me-2"></i>هزینه و نحوه پرداخت اقساط
                        </h5>
                        <div class="row g-4 text-center">
                            <div class="col-md-4">
                                <div class="p-3 bg-white shadow-sm rounded-3">
                                    <div class="small text-muted mb-1">قیمت زمین </div>
                                    <div class="h6 fw-bold">550,000,000


                                        <small>تومان</small></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 bg-white shadow-sm rounded-3">
                                    <div class="small text-muted mb-1">مبلغ جواز و ...</div>
                                    <div class="h6 fw-bold">214,000,000

                                        <small>تومان</small></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 bg-white shadow-sm rounded-3">
                                    <div class="small text-muted mb-1">مجموع هزینه ساخت </div>
                                    <div class="h6 fw-bold">3,044,275,787


                                        <small>تومان</small></div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-3 bg-success text-white shadow-sm rounded-3 border-0">
                                    <div class="small mb-1">سهم هر عضو با وام 25میلیون تومان</div>
                                    <div class="h5 fw-bold mb-0">89,000,000

                                        <small>تومان</small></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 order-1 order-lg-2">
                <div class="card shadow border-0 rounded-4 overflow-hidden h-100">
                    <div class="position-relative h-100" style="min-height: 350px;">
                        <div id="map" class="h-100 w-100" style="position: absolute; top: 0; bottom: 0;"></div>

                        <div class="position-absolute top-50 start-0 translate-middle-y ms-2" style="z-index: 1000;">
                            <div class="btn-group-vertical shadow bg-white p-1 rounded-3">
                                <button type="button" class="control-btn btn btn-outline-primary active btn-primary"
                                        onclick="changeLayer('standard', this)" title="نقشه">
                                    <i class="fas fa-map"></i>
                                </button>
                                <button type="button" class="control-btn btn btn-outline-primary"
                                        onclick="changeLayer('satellite', this)" title="ماهواره">
                                    <i class="fas fa-satellite"></i>
                                </button>
                                <button type="button" class="control-btn btn btn-outline-primary"
                                        onclick="changeLayer('hybrid', this)" title="ترکیبی">
                                    <i class="fas fa-layer-group"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card shadow-lg border-0 rounded-4 mb-5">
            <div class="card-body p-4 p-md-5">

                <h4 class="text-center fw-bold mb-4">
                    نمایی از پروژه نقشه برداری ۲
                    <div class="mx-auto mt-2 bg-primary rounded"
                         style="width:80px;height:4px;"></div>
                </h4>

                <div class="row g-4">
                    <?php foreach ($images as $img): ?>
                        <div class="col-12 col-sm-6 col-lg-4">
                            <div class="ratio ratio-4x3 rounded-3 overflow-hidden shadow-sm">
                                <img src="<?= $img ?>" class="img-fluid object-fit-cover" alt="پروژه ساختمانی">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <p class="text-center text-muted mt-4 mb-0">
                    پروژه نقشه برداری ۲ واقع در شهرک وحدت، خیابان فیروزآبادی، قطعه ۷۰۳۱
                </p>

            </div>
        </div>

        <div class="card shadow-lg border-0 rounded-4 mb-5">
            <div class="card-body p-4 p-md-5">

                <h4 class="text-center fw-bold mb-4">
                    نمایی از مشاعات پروژه نقشه برداری ۲
                    <div class="mx-auto mt-2 bg-primary rounded"
                         style="width:80px;height:4px;"></div>
                </h4>

                <div class="row g-4">
                    <?php foreach ($images2 as $img): ?>
                        <div class="col-12 col-sm-6 col-lg-4">
                            <div class="ratio ratio-4x3 rounded-3 overflow-hidden shadow-sm">
                                <img src="<?= $img ?>" class="img-fluid object-fit-cover" alt="پروژه ساختمانی">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
        </div>
    </div>



<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    const projectLocation = [<?= $latitude ?>, <?= $longitude ?>];
    let map, marker, infoLabel;

    const baseLayers = {
        standard: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }),

        satellite: L.tileLayer(
            'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            { attribution: 'Tiles © Esri', maxZoom: 19 }
        ),

        hybrid: L.tileLayer('https://{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
            subdomains: ['mt0','mt1','mt2','mt3'],
            attribution: '© Google Maps',
            maxZoom: 20
        })
    };

    function initMap() {
        map = L.map('map', {
            center: projectLocation,
            zoom: 16,
            zoomControl: false,
            layers: [baseLayers.standard]
        });

        const redPinIcon = L.divIcon({
            html: `
        <div style="position: relative; display: inline-block;">
          <div style="width: 24px; height: 24px; background: #dc2626; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>
          <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(45deg); color: white; font-size: 14px;">📍</div>
        </div>`,
            className: 'red-pin-marker',
            iconSize: [30, 30],
            iconAnchor: [15, 30]
        });

        marker = L.marker(projectLocation, { icon: redPinIcon }).addTo(map);

        const text = "پروژه نقشه برداری ۲";
        const textLength = text.length;
        const minWidth = 80;
        const maxWidth = 200;
        const calculatedWidth = Math.min(maxWidth, Math.max(minWidth, textLength * 8 + 30));

        infoLabel = L.marker(projectLocation, {
            icon: L.divIcon({
                html: `
          <div style="
            background: white;
            padding: 8px 12px;
            border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            border: 2px solid #dc2626;
            font-family: Tahoma, Arial, sans-serif;
            font-size: 12px;
            font-weight: bold;
            color: #1f2937;
            white-space: nowrap;
            width:${calculatedWidth}px
          ">📍 ${text}</div>
        `,
                className: 'text-label',
                iconSize: [120, 30],
                iconAnchor: [60, -10]
            })
        }).addTo(map);

        L.control.zoom({ position: 'topright' }).addTo(map);
        L.control.scale({ metric: true, imperial: false, position: 'bottomright' }).addTo(map);
    }

    function changeLayer(layerType, btnEl) {
        Object.values(baseLayers).forEach(layer => {
            if (map.hasLayer(layer)) map.removeLayer(layer);
        });

        baseLayers[layerType].addTo(map);

        document.querySelectorAll('.control-btn').forEach(btn => {
            btn.classList.remove('active', 'btn-primary');
            btn.classList.add('btn-outline-primary');
        });

        if (btnEl) {
            btnEl.classList.add('active', 'btn-primary');
            btnEl.classList.remove('btn-outline-primary');
        }
    }

    document.addEventListener('DOMContentLoaded', initMap);
</script>

<?php include '../partials/footer.php'; ?>
</body>
</html>
