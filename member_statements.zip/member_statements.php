<?php

session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: groupmember.php'); exit();
}


include 'partials/dashboard/header.php';


$user = [
    'FullName'     => $_SESSION['full_name'] ?? '',
    'NationalCode' => $_SESSION['NationalCode'] ?? '',
    'MemberType'   => $_SESSION['main_member'] ?? '',
    'PhoneNumber'  => $_SESSION['phone'] ?? '',
    'ProjectShare' => $_SESSION['share'] ?? '',
    'Address' => $_SESSION['address'] ?? '',
];

try {
    $pdo = new PDO("mysql:host=localhost;dbname=maskanhb_maskansazan;charset=utf8", "root", "");
    $stmt = $pdo->query("SELECT * FROM member_statements where national_code = '$user[NationalCode]'");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total_paid = 0; // متغیر برای ذخیره جمع کل
    foreach ($rows as $row) {
        $total_paid += $row['paid_amount']; // جمع زدن مقادیر در هر مرحله از حلقه
    }

} catch (PDOException $e) {
    die("خطا در اتصال: " . $e->getMessage());
}

?>
<style>
    .row {
        display: flex;
        flex-wrap: nowrap; /* جلوگیری از شکستن ردیف */
    }
    main {
        flex-grow: 1;
    }
    table thead tr th{
        text-align: right;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <!-- بخش سایدبار -->
        <div class="col-md-3 col-lg-2 p-0"> <!-- p-0 برای حذف فاصله‌های اضافی -->
            <?php include 'partials/dashboard/sidebar.php'; ?>
        </div>

        <!-- بخش محتوای اصلی -->
        <main class="col-md-9 col-lg-10 px-md-4">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="col-form-label">
                        حاصل جمع مبلغ های واریزشده
                    </label>
                </div>
                <div class="col-md-6 text-success fw-bold">
                    <label class="col-form-label">
                        <?= number_format($total_paid) ?> ریال
                    </label>
                </div>
            </div>
            <div class="table-responsive mt-4">
                <table class="table table-bordered table-hover shadow-sm">
                    <thead class="table-light">
                    <tr style="text-align: left">
                        <th>ردیف</th>
                        <th>نام عضو</th>
                        <th>عنوان قسط</th>
                        <th>تاریخ قسط</th>
                        <th>مبلغ قسط (ریال)</th>
                        <th>مبلغ پرداختی (ریال)</th>
                        <th>روش پرداخت</th>
                        <th>توضیحات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['member_name']) ?></td>
                            <td><?= htmlspecialchars($row['installment_title']) ?></td>
                            <td class="text-nowrap"><?= htmlspecialchars($row['installment_date']) ?></td>
                            <td><?= number_format($row['installment_amount']) ?></td>
                            <td><?= number_format($row['paid_amount']) ?></td>
                            <td><?= htmlspecialchars($row['payment_method'] ?? '---') ?></td>
                            <td><?= htmlspecialchars($row['description'] ?? '---') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>


